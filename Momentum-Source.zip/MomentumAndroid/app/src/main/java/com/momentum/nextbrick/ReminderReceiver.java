package com.momentum.nextbrick;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public final class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) return;
        MomentumStore store = new MomentumStore(context);
        if (!store.reminders()) return;
        ReminderScheduler.channel(context);
        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tap = PendingIntent.getActivity(context, 10, open,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification note = new Notification.Builder(context, ReminderScheduler.CHANNEL)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Your next brick")
            .setContentText(store.currentTask())
            .setStyle(new Notification.BigTextStyle().bigText(
                "Build a life you don't need to escape. " + store.currentTask()))
            .setContentIntent(tap)
            .setAutoCancel(true).build();
        NotificationManager manager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(11, note);
    }
}
