package com.momentum.nextbrick;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        ReminderScheduler.schedule(context);
        BrickWidgetProvider.updateAll(context);
    }
}
