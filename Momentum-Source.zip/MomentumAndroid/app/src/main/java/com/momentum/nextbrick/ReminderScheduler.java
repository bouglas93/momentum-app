package com.momentum.nextbrick;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

public final class ReminderScheduler {
    public static final String CHANNEL = "momentum_reminders";
    public static void channel(Context context) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.createNotificationChannel(new NotificationChannel(
            CHANNEL, "Daily next brick", NotificationManager.IMPORTANCE_DEFAULT));
    }
    public static void schedule(Context context) {
        MomentumStore store = new MomentumStore(context);
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pending = PendingIntent.getBroadcast(context, 9, intent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        alarms.cancel(pending);
        if (!store.reminders()) return;
        channel(context);
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, store.hour());
        next.set(Calendar.MINUTE, store.minute());
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= System.currentTimeMillis()) next.add(Calendar.DAY_OF_YEAR, 1);
        alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(),
            AlarmManager.INTERVAL_DAY, pending);
    }
}
