package com.momentum.nextbrick;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.time.LocalDate;

/** Local-first, no account, no server. All progress stays on the device. */
public final class MomentumStore {
    private static final String PREF = "momentum_v1";
    private static final String[] DURATIONS = {"full brick", "5-min start", "2-min start", "1-min start"};
    /** Verified, attributed quotes from primary or institutional source pages. */
    public static final class Quote {
        public final String line, author, category, source;
        Quote(String line, String author, String category, String source) {
            this.line = line; this.author = author; this.category = category; this.source = source;
        }
    }
    private static final Quote[] QUOTES = {
        new Quote("You have to show up before inspiration will.", "James Clear", "Action", "https://jamesclear.com/quotes/you-have-to-show-up-before-inspiration-will"),
        new Quote("Failure and invention are inseparable twins.", "Jeff Bezos", "Resilience", "https://ir.aboutamazon.com/files/doc_financials/annual/2015-Letter-to-Shareholders.PDF"),
        new Quote("Your time is limited, so don't waste it living someone else's life.", "Steve Jobs", "Purpose", "https://news.stanford.edu/stories/2005/06/steve-jobs-2005-graduates-stay-hungry-stay-foolish"),
        new Quote("Each of us has a chance to be new tomorrow, if we care enough.", "Seth Godin", "Hope", "https://seths.blog/author/seth-godin/page/253/"),
        new Quote("Working hard for something we love is called passion.", "Simon Sinek", "Purpose", "https://simonsinek.com/"),
        new Quote("Discipline equals freedom.", "Jocko Willink", "Determination", "https://www.jockopodcast.com/obey-your-own-orders-discipline-vs-the-war-in-your-head/"),
        new Quote("Grit is living life like it's a marathon, not a sprint.", "Angela Duckworth", "Perseverance", "https://www.ted.com/talks/angela_lee_duckworth_grit_the_power_of_passion_and_perseverance?view=transcript"),
        new Quote("You do not rise to the level of your goals. You fall to the level of your systems.", "James Clear", "Growth", "https://jamesclear.com/atomic-habits-summary"),
        new Quote("The magic of learning is that it's yours.", "Seth Godin", "Learning", "https://seths.blog/author/seth-godin/page/251/"),
        new Quote("Grit is passion and perseverance for very long-term goals.", "Angela Duckworth", "Resilience", "https://blog.ted.com/your-ted-inspired-new-years-resolutions/comment-page-2/"),
        new Quote("The way to get startup ideas is not to try to think of startup ideas.", "Paul Graham", "Entrepreneurship", "https://paulgraham.com/startupideas.html"),
        new Quote("Decide the type of person you want to be. Prove it to yourself with small wins.", "James Clear", "Growth", "https://jamesclear.com/3-2-1/january-1-2026")
    };
    private final SharedPreferences prefs;

    public MomentumStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** Rotates locally and can be advanced manually. All quotes work offline. */
    public Quote currentQuote() {
        long day = LocalDate.now().toEpochDay();
        long offset = prefs.getLong("quote_offset", 0L);
        return QUOTES[(int)Math.floorMod(day + offset, (long)QUOTES.length)];
    }
    public String quote() { return currentQuote().line; }
    public void nextQuote() {
        prefs.edit().putLong("quote_offset", prefs.getLong("quote_offset", 0L) + 1L).commit();
    }

    /** Manual podcast entry: Spotify app opens the link; no cloud subscription or sync. */
    public String podcastTitle() { return prefs.getString("podcast_title", ""); }
    public String podcastUrl() { return prefs.getString("podcast_url", ""); }
    public String podcastLearning() { return prefs.getString("podcast_learning", ""); }
    public String podcastAction() { return prefs.getString("podcast_action", ""); }
    public boolean podcastListened() { return prefs.getBoolean("podcast_listened", false); }
    public void savePodcast(String title, String url) {
        if (!title.trim().equals(podcastTitle()) || !url.trim().equals(podcastUrl())) {
            prefs.edit().putString("podcast_title", title.trim()).putString("podcast_url", url.trim())
                .putString("podcast_learning", "").putString("podcast_action", "")
                .putBoolean("podcast_listened", false).commit();
        }
    }
    public void reflectPodcast(String learning, String action) {
        prefs.edit().putString("podcast_learning", learning.trim()).putString("podcast_action", action.trim())
            .putBoolean("podcast_listened", true).commit();
    }

    public String goal() { return prefs.getString("goal", "Build a profitable online business"); }
    public String milestone() { return prefs.getString("milestone", "Publish useful content consistently"); }
    public String why() { return prefs.getString("why", "More freedom and time for what matters"); }
    public String brick() { return prefs.getString("brick", "Outline my next article"); }
    public int level() { return Math.max(0, Math.min(3, prefs.getInt("level", 0))); }
    public boolean finished() { return prefs.getBoolean("finished", false); }
    public boolean reminders() { return prefs.getBoolean("reminders", false); }
    public int hour() { return prefs.getInt("hour", 22); }
    public int minute() { return prefs.getInt("minute", 0); }
    public String[] steps() {
        return new String[]{brick(),
            prefs.getString("small", "List three points the article should cover"),
            prefs.getString("tiny", "Write one bullet point"),
            prefs.getString("micro", "Open my notes and write a working title")};
    }
    public String currentTask() {
        if (finished()) return "Brick completed. Choose your next one.";
        return steps()[level()];
    }
    public String currentDuration() { return DURATIONS[level()]; }

    public void saveVision(String goal, String milestone, String why) {
        prefs.edit().putString("goal", goal.trim()).putString("milestone", milestone.trim())
            .putString("why", why.trim()).commit();
    }
    public void saveBrick(String[] steps) {
        if (steps.length < 4) throw new IllegalArgumentException("Four step sizes are required");
        prefs.edit().putString("brick", steps[0].trim()).putString("small", steps[1].trim())
            .putString("tiny", steps[2].trim()).putString("micro", steps[3].trim())
            .putInt("level", 0).putBoolean("finished", false).commit();
    }
    public boolean makeSmaller() {
        if (finished() || level() == 3) return false;
        prefs.edit().putInt("level", level() + 1).commit();
        return true;
    }

    /** Smaller tasks count as starts, NOT completed bricks. The original goal remains active. */
    public boolean completeStep() {
        if (finished()) return false;
        String description = currentTask();
        if (level() > 0) {
            appendEvent("start", description);
            prefs.edit().putInt("level", level() - 1).commit();
            return false;
        }
        appendEvent("brick", description);
        prefs.edit().putBoolean("finished", true).commit();
        return true;
    }

    /** User-controlled local backup. No network access or paid service. */
    public String exportJson() {
        JSONObject backup = new JSONObject();
        try {
            backup.put("format", "momentum-backup-v1");
            backup.put("goal", goal());
            backup.put("milestone", milestone());
            backup.put("why", why());
            String[] step = steps();
            backup.put("brick", step[0]);
            backup.put("small", step[1]);
            backup.put("tiny", step[2]);
            backup.put("micro", step[3]);
            backup.put("level", level());
            backup.put("finished", finished());
            backup.put("reminders", reminders());
            backup.put("hour", hour());
            backup.put("minute", minute());
            backup.put("history", history());
            backup.put("quote_offset", prefs.getLong("quote_offset", 0L));
            backup.put("podcast_title", podcastTitle());
            backup.put("podcast_url", podcastUrl());
            backup.put("podcast_learning", podcastLearning());
            backup.put("podcast_action", podcastAction());
            backup.put("podcast_listened", podcastListened());
            backup.put("podcast_feed_json", prefs.getString("podcast_feed_json", ""));
            backup.put("podcast_feed_url", prefs.getString("podcast_feed_url", PodcastLibrary.DEFAULT_URL));
            backup.put("podcast_show_ratings", prefs.getString("podcast_show_ratings", "{}"));
            backup.put("podcast_skipped", prefs.getString("podcast_skipped", "[]"));
            backup.put("podcast_selected", prefs.getString("podcast_selected", ""));
        } catch (org.json.JSONException e) { throw new IllegalStateException(e); }
        return backup.toString();
    }
    /** Validate the backup before overwriting current local data. */
    public void importJson(String json) throws org.json.JSONException {
        JSONObject backup = new JSONObject(json);
        if (!"momentum-backup-v1".equals(backup.optString("format")))
            throw new org.json.JSONException("Not a Momentum backup file");
        String goal = backup.getString("goal").trim();
        String milestone = backup.getString("milestone").trim();
        String why = backup.getString("why").trim();
        String brick = backup.getString("brick").trim();
        String small = backup.getString("small").trim();
        String tiny = backup.getString("tiny").trim();
        String micro = backup.getString("micro").trim();
        int level = backup.getInt("level");
        int hour = backup.getInt("hour");
        int minute = backup.getInt("minute");
        if (goal.isEmpty() || brick.isEmpty() || small.isEmpty() || tiny.isEmpty() || micro.isEmpty()
            || level < 0 || level > 3 || hour < 0 || hour > 23 || minute < 0 || minute > 59)
            throw new org.json.JSONException("Invalid backup contents");
        JSONArray history = backup.getJSONArray("history");
        if (history.length() > 20000) throw new org.json.JSONException("History too large");
        prefs.edit().putString("goal", goal).putString("milestone", milestone).putString("why", why)
            .putString("brick", brick).putString("small", small).putString("tiny", tiny)
            .putString("micro", micro).putInt("level", level)
            .putBoolean("finished", backup.getBoolean("finished"))
            .putBoolean("reminders", backup.getBoolean("reminders"))
            .putInt("hour", hour).putInt("minute", minute)
            .putString("history", history.toString())
            .putLong("quote_offset", backup.optLong("quote_offset", 0L))
            .putString("podcast_title", backup.optString("podcast_title", ""))
            .putString("podcast_url", backup.optString("podcast_url", ""))
            .putString("podcast_learning", backup.optString("podcast_learning", ""))
            .putString("podcast_action", backup.optString("podcast_action", ""))
            .putBoolean("podcast_listened", backup.optBoolean("podcast_listened", false))
            .putString("podcast_feed_json", backup.optString("podcast_feed_json", ""))
            .putString("podcast_feed_url", backup.optString("podcast_feed_url", PodcastLibrary.DEFAULT_URL))
            .putString("podcast_show_ratings", backup.optString("podcast_show_ratings", "{}"))
            .putString("podcast_skipped", backup.optString("podcast_skipped", "[]"))
            .putString("podcast_selected", backup.optString("podcast_selected", ""))
            .commit();
    }

    public void setReminder(boolean enabled, int h, int m) {
        prefs.edit().putBoolean("reminders", enabled).putInt("hour", h).putInt("minute", m).commit();
    }

    private synchronized void appendEvent(String kind, String task) {
        JSONArray events = history();
        JSONObject event = new JSONObject();
        try {
            event.put("time", System.currentTimeMillis());
            event.put("type", kind);
            event.put("task", task);
            events.put(event);
        } catch (Exception ignored) { return; }
        prefs.edit().putString("history", events.toString()).commit();
    }
    public JSONArray history() {
        try { return new JSONArray(prefs.getString("history", "[]")); }
        catch (Exception ignored) { return new JSONArray(); }
    }
    public int count(String type, int days) {
        JSONArray history = history();
        long since = System.currentTimeMillis() - (long)days * 24L * 60L * 60L * 1000L;
        int n = 0;
        for (int i = 0; i < history.length(); i++) {
            JSONObject item = history.optJSONObject(i);
            if (item != null && type.equals(item.optString("type")) && item.optLong("time") >= since) n++;
        }
        return n;
    }
    public ArrayList<String> recentEvents(int max) {
        JSONArray history = history();
        ArrayList<String> out = new ArrayList<>();
        for (int i = history.length() - 1; i >= 0 && out.size() < max; i--) {
            JSONObject item = history.optJSONObject(i);
            if (item != null) {
                String label = "brick".equals(item.optString("type")) ? "BRICK FINISHED" : "STARTING STEP";
                out.add(label + "  ·  " + item.optString("task"));
            }
        }
        return out;
    }

    /** Local starter suggestions, deliberately not advertised as AI. User can edit all four. */
    public static String[] suggest(String full) {
        String lower = full.toLowerCase(java.util.Locale.US);
        if (contains(lower, "blog", "article", "write", "post", "outline", "content"))
            return new String[]{full, "List three ideas or sections", "Write one bullet point", "Open notes and type a working title"};
        if (contains(lower, "job", "apply", "resume", "career"))
            return new String[]{full, "Find one relevant opportunity", "Save one listing to review", "Open the job listings page"};
        if (contains(lower, "budget", "loan", "debt", "money", "save", "spend"))
            return new String[]{full, "Choose one number to review", "Open your budget or statements", "Write down one question about the numbers"};
        if (contains(lower, "workout", "gym", "walk", "exercise", "run"))
            return new String[]{full, "Prepare for five minutes of movement", "Put on workout clothes", "Put your shoes by the door"};
        if (contains(lower, "clean", "fix", "repair", "paint", "bathroom", "house", "home"))
            return new String[]{full, "Identify and gather the next tools", "Name the first physical action", "Walk to the work area"};
        if (contains(lower, "read", "learn", "study", "course"))
            return new String[]{full, "Choose one short section", "Read one paragraph", "Open the learning material"};
        return new String[]{full, "Work on this for just five minutes", "Write down the first physical action", "Open a note and write its title"};
    }
    private static boolean contains(String text, String... keywords) {
        for (String keyword : keywords) if (text.contains(keyword)) return true;
        return false;
    }
}
