package com.momentum.nextbrick;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public final class BrickWidgetProvider extends AppWidgetProvider {
    public static final String SMALLER = "com.momentum.nextbrick.MAKE_SMALLER";
    public static final String DONE = "com.momentum.nextbrick.COMPLETE_STEP";
    public static final String NEXT_QUOTE = "com.momentum.nextbrick.NEXT_QUOTE";

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (SMALLER.equals(action) || DONE.equals(action) || NEXT_QUOTE.equals(action)) {
            MomentumStore store = new MomentumStore(context);
            if (SMALLER.equals(action)) store.makeSmaller();
            else if (NEXT_QUOTE.equals(action)) store.nextQuote();
            else store.completeStep();
            updateAll(context);
            return;
        }
        super.onReceive(context, intent);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }

    private static PendingIntent action(Context context, String action, int request) {
        Intent intent = new Intent(context, BrickWidgetProvider.class);
        intent.setAction(action);
        return PendingIntent.getBroadcast(context, request, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent launch(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(context, 3, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private static void update(Context context, AppWidgetManager manager, int id) {
        MomentumStore store = new MomentumStore(context);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_brick);
        views.setTextViewText(R.id.widget_task, store.currentTask());
        org.json.JSONObject podcast = new PodcastLibrary(context).current();
        views.setTextViewText(R.id.widget_podcast, podcast == null ? "🎧  Open app for Tonight's Listen" :
            "🎧  " + podcast.optString("show") + " · " + podcast.optString("title"));
        views.setOnClickPendingIntent(R.id.widget_podcast, launch(context));
        views.setTextViewText(R.id.widget_quote, "“" + store.quote() + "”\n— " + store.currentQuote().author + "   ↻");
        views.setOnClickPendingIntent(R.id.widget_quote, action(context, NEXT_QUOTE, 4));
        views.setTextViewText(R.id.widget_stage, store.finished() ? "BRICK COMPLETE" :
            "STEP " + (store.level() + 1) + "/4  ·  " + store.currentDuration());
        views.setTextViewText(R.id.widget_goal, "GOAL  ·  " + store.goal());
        views.setTextViewText(R.id.widget_smaller, store.finished() ? "Set next brick" :
            store.level() == 3 ? "Open app ↗" : "↓ Make smaller");
        views.setTextViewText(R.id.widget_done, store.finished() ? "Open app ↗" : "Done ✓");
        views.setOnClickPendingIntent(R.id.widget_root, launch(context));
        views.setOnClickPendingIntent(R.id.widget_smaller,
            store.finished() || store.level() == 3 ? launch(context) : action(context, SMALLER, 1));
        views.setOnClickPendingIntent(R.id.widget_done,
            store.finished() ? launch(context) : action(context, DONE, 2));
        manager.updateAppWidget(id, views);
    }
    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, BrickWidgetProvider.class));
        for (int id : ids) update(context, manager, id);
    }
}
