package com.momentum.nextbrick;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import org.json.JSONObject;

/** Opens the recommended episode; first syncs if no recommendation is cached. */
public final class PodcastLaunchActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        PodcastLibrary library = new PodcastLibrary(this);
        JSONObject pick = library.current();
        if (valid(pick)) { play(pick.optString("url")); return; }
        Toast.makeText(this, "Loading tonight's podcast…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            library.fetch();
            JSONObject refreshed = library.current();
            runOnUiThread(() -> {
                if (valid(refreshed)) play(refreshed.optString("url"));
                else {
                    Toast.makeText(this, "No podcast available. Check your feed in Momentum.",
                        Toast.LENGTH_LONG).show();
                    finish();
                }
            });
        }, "MomentumPodcastOpen").start();
    }
    private static boolean valid(JSONObject pick) {
        if (pick == null) return false;
        Uri uri = Uri.parse(pick.optString("url", ""));
        return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null;
    }
    private void play(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "No browser or podcast app can open this link.",
                Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
