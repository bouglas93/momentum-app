package com.momentum.nextbrick;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/** Simple native Android MVP. No account, no paid SDKs, no network needed. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(16,23,34);
    private static final int CARD = Color.rgb(26,37,54);
    private static final int SUB = Color.rgb(34,48,68);
    private static final int GOLD = Color.rgb(235,196,119);
    private static final int WHITE = Color.rgb(245,247,251);
    private static final int MUTED = Color.rgb(170,184,202);
    private static final int GREEN = Color.rgb(123,224,178);
    private MomentumStore store;
    private PodcastLibrary podcasts;
    private boolean fetchingPodcasts = false;
    private static final int EXPORT_BACKUP = 60;
    private static final int IMPORT_BACKUP = 61;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new MomentumStore(this);
        podcasts = new PodcastLibrary(this);
        PodcastRefreshJob.schedule(this);
        ReminderScheduler.channel(this);
        render();
    }
    @Override public void onResume() {
        super.onResume();
        if (store != null) render(); // reflect widget taps while app was away
        if (podcasts != null && System.currentTimeMillis() - podcasts.lastSync() > 2L * 60L * 60L * 1000L)
            requestPodcastRefresh(false);
    }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setFontFeatureSettings("kern");
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setLineSpacing(dp(2), 1.0f);
        return t;
    }
    private void add(LinearLayout parent, View view, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(top);
        parent.addView(view, p);
    }
    private LinearLayout card(int bg, int pad) {
        LinearLayout c = column();
        c.setPadding(dp(pad), dp(pad), dp(pad), dp(pad));
        c.setBackground(shape(bg, 20));
        return c;
    }
    private Button button(String title, boolean primary, Runnable click) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setTextColor(primary ? BG : WHITE);
        b.setBackground(shape(primary ? GOLD : SUB, 13));
        b.setMinHeight(dp(50));
        b.setPadding(dp(12), dp(9), dp(12), dp(9));
        b.setOnClickListener(v -> click.run());
        return b;
    }
    private void header(LinearLayout parent, String heading, String note) {
        add(parent, text(heading, 12, GOLD, true), 25);
        if (note != null) add(parent, text(note, 14, MUTED, false), 7);
    }
    private void refresh() { BrickWidgetProvider.updateAll(this); render(); }
    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column();
        root.setPadding(dp(20), dp(28), dp(20), dp(36));
        scroll.addView(root);

        TextView brand = text("✦   M O M E N T U M", 13, GOLD, true);
        add(root, brand, 0);
        add(root, text("Build a life you don't need to escape.", 29, WHITE, true), 22);
        add(root, text("One small step at a time.", 15, MUTED, false), 9);

        header(root, "WORDS FOR THE WORK", "A short line for today. Tap to change it whenever you want.");
        LinearLayout quoteCard = card(CARD, 16);
        MomentumStore.Quote q = store.currentQuote();
        add(quoteCard, text("“" + q.line + "”", 17, WHITE, true), 0);
        add(quoteCard, text("— " + q.author + "  ·  " + q.category, 13, GOLD, true), 9);
        add(quoteCard, button("↻   Another quote", false, () -> {
            store.nextQuote(); refresh();
        }), 12);
        add(quoteCard, button("Verify source ↗", false, () -> openUrl(q.source)), 8);
        add(root, quoteCard, 10);

        header(root, "YOUR DIRECTION", null);
        LinearLayout vision = card(CARD, 19);
        add(vision, text(store.goal(), 19, WHITE, true), 0);
        add(vision, text("CURRENT MILESTONE", 11, GOLD, true), 14);
        add(vision, text(store.milestone(), 14, MUTED, false), 5);
        add(vision, text("WHY IT MATTERS", 11, GOLD, true), 14);
        add(vision, text(store.why(), 14, MUTED, false), 5);
        add(vision, button("Edit my direction", false, this::editVision), 18);
        add(root, vision, 11);

        header(root, "YOUR NEXT BRICK", "Your next step is selected automatically from your goal.");
        LinearLayout task = card(CARD, 19);
        add(task, text("STEP " + (store.level() + 1) + " OF 4  ·  " + store.currentDuration().toUpperCase(Locale.US),
            11, GOLD, true), 0);
        add(task, text(store.currentTask(), 23, WHITE, true), 13);
        add(task, text(store.level() > 0 ? "This is a starting step. Your full brick remains ahead." :
                "Finish this, and Momentum will automatically give you the next brick.",
                13, MUTED, false), 12);
        add(task, text("ROADMAP  ·  " + store.roadmapName() + "  ·  Offline steps", 11, GOLD, true), 10);
        add(task, button("✓   Done → Show my next step", true, () -> {
            boolean full = store.completeStep();
            refresh();
            Toast.makeText(this, full ? "Brick complete. Your next one is ready." :
                "Starting step done — one level closer", Toast.LENGTH_SHORT).show();
        }), 17);
        if (store.level() < 3) {
            add(task, button("↓   Make it smaller", false, () -> {
                store.makeSmaller(); refresh();
            }), 9);
        } else add(task, text("Your smallest start is ready. Do it, then move up a level.",
            12, MUTED, false), 12);
        add(task, button("Different step (no credit)", false, () -> {
            store.skipBrick();
            refresh();
            Toast.makeText(this, "Skipped — no progress recorded", Toast.LENGTH_SHORT).show();
        }), 10);
        add(task, button("Edit this step (optional)", false, this::editBrick), 8);
        add(root, task, 10);

        LinearLayout staircase = card(SUB, 16);
        add(staircase, text("THE PATH BACK UP", 11, GOLD, true), 0);
        String[] names = {"Full brick", "Smaller", "Tiny", "Just start"};
        String[] steps = store.steps();
        for (int i = 3; i >= 0; i--) {
            String prefix = !store.finished() && store.level() == i ? "●  " : "○  ";
            add(staircase, text(prefix + names[i] + "  ·  " + steps[i], 12,
                !store.finished() && store.level() == i ? WHITE : MUTED, false), i == 3 ? 11 : 8);
        }
        add(root, staircase, 12);

        header(root, "TONIGHT'S LISTEN", "A favorite show or a new discovery. One lesson you can use.");
        LinearLayout podcast = card(CARD, 16);
        org.json.JSONObject pick = podcasts.current();
        if (pick != null) {
            String kind = "favorite".equals(pick.optString("kind")) ? "FROM YOUR FAVORITES" : "NEW DISCOVERY";
            add(podcast, text(kind + "  ·  " + pick.optString("show"), 12, GOLD, true), 0);
            add(podcast, text(pick.optString("title"), 19, WHITE, true), 10);
            int minutes = pick.optInt("duration_minutes", 0);
            String duration = minutes <= 0 ? "Length not provided" : (minutes + " minutes");
            add(podcast, text(duration + "  ·  " + pick.optString("released", "Date unknown"), 12, MUTED, false), 8);
            add(podcast, text(pick.optString("reason"), 13, GREEN, false), 10);
            String desc = pick.optString("description");
            if (!desc.isEmpty()) add(podcast, text(desc.length()>280 ? desc.substring(0,280) + "…" : desc, 13, MUTED, false), 9);
            add(podcast, text("Ranked using public episode metadata, not personally reviewed.", 11, MUTED, false), 9);
            add(podcast, button("▶   Open episode", true, () -> openUrl(pick.optString("url"))), 13);
            add(podcast, button("Find this episode on Spotify (search)", false, () -> openUrl(pick.optString("spotify_search"))), 9);
            if (pick.optString("url").equals(store.podcastUrl())) {
                if (!store.podcastLearning().isEmpty()) {
                    add(podcast, text("ONE TAKEAWAY", 11, GOLD, true), 16);
                    add(podcast, text(store.podcastLearning(), 13, WHITE, false), 5);
                }
                if (!store.podcastAction().isEmpty()) {
                    add(podcast, text("ONE ACTION", 11, GOLD, true), 14);
                    add(podcast, text(store.podcastAction(), 13, WHITE, false), 5);
                    add(podcast, button("Turn action into a Next Brick", false, this::usePodcastActionAsBrick), 10);
                }
            }
            add(podcast, button("Save a takeaway and action", false, () -> {
                store.savePodcast(pick.optString("title"),pick.optString("url"));
                reflectPodcast();
            }), 9);
            add(podcast, button("👍   More like this show", false, () -> {
                podcasts.rate(true);
                Toast.makeText(this,"Show preference saved on this phone",Toast.LENGTH_SHORT).show();
                refresh();
            }), 9);
            add(podcast, button("↓   Not for me · another pick", false, () -> {
                podcasts.rate(false); refresh();
            }), 9);
        } else {
            add(podcast, text("No automatic pick available yet", 17, WHITE, true), 0);
            add(podcast, text("Set up the free GitHub podcast feed, then tap Refresh. You can still add episodes manually.", 13, MUTED, false), 10);
            if (!store.podcastTitle().isEmpty()) {
                add(podcast, text(store.podcastTitle(), 14, WHITE, true), 11);
                add(podcast, button("▶   Open saved episode", true, () -> openUrl(store.podcastUrl())), 9);
            }
            add(podcast, button("Add an episode manually", false, this::editPodcast), 11);
        }
        String updateText = podcasts.lastSync()==0 ? "Not synced yet" :
            "Last sync: " + new SimpleDateFormat("MMM d, h:mm a",Locale.getDefault()).format(new java.util.Date(podcasts.lastSync()));
        add(podcast, text(updateText, 11, MUTED, false), 12);
        if (!podcasts.error().isEmpty()) add(podcast, text("Feed status: " + podcasts.error(), 11, MUTED, false), 7);
        add(podcast, button("↻   Refresh podcast recommendations", false, () -> requestPodcastRefresh(true)), 9);
        add(podcast, button("Edit feed address", false, this::editPodcastFeedUrl), 9);
        add(root, podcast, 11);

        header(root, "YOUR REAL PROGRESS", "Smaller starts and finished bricks are counted separately.");
        LinearLayout counts = new LinearLayout(this);
        counts.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout bricks = card(CARD, 16);
        add(bricks, text("" + store.count("brick", 7), 30, GREEN, true), 0);
        add(bricks, text("Bricks finished", 12, MUTED, false), 5);
        LinearLayout starts = card(CARD, 16);
        add(starts, text("" + store.count("start", 7), 30, GOLD, true), 0);
        add(starts, text("Starting steps", 12, MUTED, false), 5);
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        left.rightMargin = dp(8);
        counts.addView(bricks, left);
        counts.addView(starts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        add(root, counts, 12);
        add(root, text("Last 7 days · No fake streaks or points for opening the app.", 12, MUTED, false), 10);
        java.util.ArrayList<String> events = store.recentEvents(4);
        if (!events.isEmpty()) {
            LinearLayout recents = card(CARD, 16);
            add(recents, text("RECENT ACTIONS", 11, GOLD, true), 0);
            for (String event : events) add(recents, text("•  " + event, 12, MUTED, false), 9);
            add(root, recents, 12);
        }
        header(root, "GENTLE REMINDER", "Optional daily notification. The widget stays visible on your home screen.");
        LinearLayout reminders = card(CARD, 16);
        SimpleDateFormat fmt = new SimpleDateFormat("h:mm a", Locale.getDefault());
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.set(java.util.Calendar.HOUR_OF_DAY, store.hour());
        cal.set(java.util.Calendar.MINUTE, store.minute());
        add(reminders, text((store.reminders() ? "On  ·  " : "Off  ·  ") + fmt.format(cal.getTime()), 16, WHITE, true), 0);
        add(reminders, button(store.reminders() ? "Turn daily reminder off" : "Turn daily reminder on",
            false, this::toggleReminder), 13);
        add(reminders, button("Change reminder time", false, this::chooseReminderTime), 8);
        add(root, reminders, 11);
        header(root, "YOUR DATA", "No account or cloud subscription. Save a backup before reinstalling or updating from a new build.");
        LinearLayout data = card(CARD, 16);
        add(data, button("Export backup file", false, this::exportBackup), 0);
        add(data, button("Restore from backup", false, this::chooseBackup), 9);
        add(root, data, 10);
        add(root, text("Momentum suggests each next brick from prewritten offline roadmaps; it is not an AI coach and won't know whether a real-world step succeeded. Goals, progress and quotes work offline. Podcasts use your free GitHub feed and require internet to refresh or open.",
            12, MUTED, false), 24);
        setContentView(scroll);
    }
    private void requestPodcastRefresh(boolean force) {
        if (fetchingPodcasts) return;
        if (!force && System.currentTimeMillis()-podcasts.lastSync() < 2L*60*60*1000L) return;
        fetchingPodcasts = true;
        if (force) Toast.makeText(this,"Checking podcast feed…",Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            boolean ok = podcasts.fetch();
            runOnUiThread(() -> {
                fetchingPodcasts = false;
                if (isFinishing() || isDestroyed()) return;
                if (force) Toast.makeText(this, ok ? "Podcast feed updated" :
                    "Couldn't fetch; last saved pick remains available", Toast.LENGTH_LONG).show();
                if (ok) BrickWidgetProvider.updateAll(this);
                render();
            });
        }, "MomentumManualPodcastSync").start();
    }
    private void editPodcastFeedUrl() {
        EditText input = field(podcasts.feedUrl(),"https://username.github.io/repo/recommendations.json");
        LinearLayout fields=column();
        labeledField(fields,"PUBLIC GITHUB PAGES FEED URL",input);
        new AlertDialog.Builder(this).setTitle("Podcast feed address")
            .setView(dialogView(fields))
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Save",(dialog,which)->{
                try {
                    podcasts.setFeedUrl(input.getText().toString());
                    requestPodcastRefresh(true);
                } catch (IllegalArgumentException err) {
                    Toast.makeText(this,err.getMessage(),Toast.LENGTH_LONG).show();
                }
            }).show();
    }
    private void openUrl(String url) {
        if (url == null || !url.startsWith("https://")) {
            Toast.makeText(this, "Enter a valid HTTPS link first", Toast.LENGTH_SHORT).show(); return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "No app available to open this link", Toast.LENGTH_SHORT).show();
        }
    }
    private void editPodcast() {
        LinearLayout fields = column();
        EditText title = field(store.podcastTitle(), "Episode name");
        EditText url = field(store.podcastUrl(), "https://open.spotify.com/episode/...");
        labeledField(fields, "EPISODE TITLE", title);
        labeledField(fields, "SPOTIFY EPISODE URL", url);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Tonight's Listen")
            .setView(dialogView(fields)).setNegativeButton("Cancel", null)
            .setPositiveButton("Save episode", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String t = title.getText().toString().trim();
            String u = url.getText().toString().trim();
            android.net.Uri parsed = Uri.parse(u);
            String host = parsed.getHost();
            if (t.isEmpty() || !"https".equalsIgnoreCase(parsed.getScheme()) ||
                    host == null || !(host.equalsIgnoreCase("open.spotify.com") || host.equalsIgnoreCase("spotify.link"))) {
                Toast.makeText(this, "Add a title and a Spotify episode URL", Toast.LENGTH_LONG).show(); return;
            }
            store.savePodcast(t, u);
            dialog.dismiss(); refresh();
        }));
        dialog.show();
    }
    private void reflectPodcast() {
        LinearLayout fields = column();
        EditText learning = field(store.podcastLearning(), "What's one thing worth remembering?");
        EditText action = field(store.podcastAction(), "What's one small action you could take?");
        labeledField(fields, "ONE TAKEAWAY", learning);
        labeledField(fields, "ONE REAL ACTION (OPTIONAL)", action);
        new AlertDialog.Builder(this).setTitle("Turn listening into learning")
            .setView(dialogView(fields))
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", (d, w) -> {
                store.reflectPodcast(learning.getText().toString(), action.getText().toString());
                refresh();
            }).show();
    }
    private void usePodcastActionAsBrick() {
        String action = store.podcastAction();
        if (action.isEmpty()) return;
        new AlertDialog.Builder(this).setTitle("Replace your current Next Brick?")
            .setMessage("This creates a new Next Brick from the podcast action. Your existing brick and its current step will be replaced. Your progress history stays saved.")
            .setNegativeButton("Keep current brick", null)
            .setPositiveButton("Use podcast action", (d, w) -> {
                store.saveBrick(MomentumStore.suggest(action));
                refresh();
            }).show();
    }

    private EditText field(String value, String hint) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setHint(hint);
        e.setTextColor(WHITE);
        e.setHintTextColor(MUTED);
        e.setTextSize(15);
        e.setSingleLine(false);
        e.setMinLines(1);
        e.setMaxLines(3);
        e.setPadding(dp(8), dp(11), dp(8), dp(11));
        return e;
    }
    private void labeledField(LinearLayout parent, String name, EditText field) {
        add(parent, text(name, 12, GOLD, true), 14);
        add(parent, field, 3);
    }
    private ScrollView dialogView(LinearLayout content) {
        ScrollView scroller = new ScrollView(this);
        content.setPadding(dp(18), dp(8), dp(18), dp(12));
        scroller.addView(content);
        return scroller;
    }
    private void editVision() {
        LinearLayout fields = column();
        EditText goal = field(store.goal(), "Your big goal");
        EditText milestone = field(store.milestone(), "Current milestone");
        EditText why = field(store.why(), "Why it matters");
        labeledField(fields, "BIG GOAL", goal);
        labeledField(fields, "CURRENT MILESTONE", milestone);
        labeledField(fields, "MY WHY", why);
        new AlertDialog.Builder(this).setTitle("Choose your direction")
            .setView(dialogView(fields))
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", (d, w) -> {
                if (goal.getText().toString().trim().isEmpty()) {
                    Toast.makeText(this, "Your goal cannot be blank", Toast.LENGTH_SHORT).show(); return;
                }
                store.saveVision(goal.getText().toString(), milestone.getText().toString(), why.getText().toString());
                refresh();
            }).show();
    }
    private void editBrick() {
        LinearLayout fields = column();
        String[] steps = store.steps();
        EditText[] entries = new EditText[4];
        String[] names = {"FULL BRICK", "SMALLER STEP", "TINY STEP", "JUST START"};
        for (int i = 0; i < 4; i++) {
            entries[i] = field(steps[i], names[i]);
            labeledField(fields, names[i], entries[i]);
        }
        add(fields, text("Momentum advances automatically. Edit only if a suggested step doesn't fit. Offline suggestions are prewritten, not AI.",
            12, MUTED, false), 14);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Adjust this brick (optional)")
            .setView(dialogView(fields))
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Suggest sizes", null)
            .setPositiveButton("Use this brick", null).create();
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                String full = entries[0].getText().toString().trim();
                if (full.isEmpty()) {
                    Toast.makeText(this, "Enter the full brick first", Toast.LENGTH_SHORT).show(); return;
                }
                String[] suggestion = MomentumStore.suggest(full);
                for (int i = 1; i < 4; i++) entries[i].setText(suggestion[i]);
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String full = entries[0].getText().toString().trim();
                if (full.isEmpty()) {
                    Toast.makeText(this, "Enter your full brick first", Toast.LENGTH_SHORT).show(); return;
                }
                String[] suggestions = MomentumStore.suggest(full);
                String[] out = new String[4];
                out[0] = full;
                for (int i = 1; i < 4; i++) {
                    String choice = entries[i].getText().toString().trim();
                    out[i] = choice.isEmpty() ? suggestions[i] : choice;
                }
                store.saveBrick(out);
                dialog.dismiss();
                refresh();
            });
        });
        dialog.show();
    }
    private void exportBackup() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "momentum-backup.json");
        startActivityForResult(intent, EXPORT_BACKUP);
    }
    private void chooseBackup() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, IMPORT_BACKUP);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        try {
            if (request == EXPORT_BACKUP) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData())) {
                    if (stream == null) throw new java.io.IOException("Cannot open file");
                    stream.write(store.exportJson().getBytes(StandardCharsets.UTF_8));
                }
                Toast.makeText(this, "Backup saved", Toast.LENGTH_LONG).show();
            } else if (request == IMPORT_BACKUP) {
                ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                try (InputStream stream = getContentResolver().openInputStream(data.getData())) {
                    if (stream == null) throw new java.io.IOException("Cannot open file");
                    byte[] chunk = new byte[4096];
                    int len;
                    while ((len = stream.read(chunk)) != -1) {
                        if (buffer.size() + len > 1024 * 1024)
                            throw new java.io.IOException("Backup file is too large");
                        buffer.write(chunk, 0, len);
                    }
                }
                final String contents = buffer.toString("UTF-8");
                // Check format before asking for confirmation.
                org.json.JSONObject preview = new org.json.JSONObject(contents);
                if (!"momentum-backup-v1".equals(preview.optString("format")))
                    throw new java.io.IOException("Not a Momentum backup");
                new AlertDialog.Builder(this).setTitle("Restore Momentum?")
                    .setMessage("This will replace your current goals, steps and activity history with the backup. Continue?")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Restore", (d, w) -> {
                        try {
                            store.importJson(contents);
                            ReminderScheduler.schedule(this);
                            refresh();
                            Toast.makeText(this, "Backup restored", Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                            Toast.makeText(this, "Backup invalid: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Backup error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    private void toggleReminder() {
        if (store.reminders()) {
            store.setReminder(false, store.hour(), store.minute());
            ReminderScheduler.schedule(this); render(); return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 41);
            return;
        }
        enableReminder();
    }
    private void enableReminder() {
        store.setReminder(true, store.hour(), store.minute());
        ReminderScheduler.schedule(this); render();
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 41) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) enableReminder();
            else Toast.makeText(this, "Notifications are not enabled", Toast.LENGTH_SHORT).show();
        }
    }
    private void chooseReminderTime() {
        new TimePickerDialog(this, (view, hour, minute) -> {
            store.setReminder(store.reminders(), hour, minute);
            ReminderScheduler.schedule(this); render();
        }, store.hour(), store.minute(), false).show();
    }
}
