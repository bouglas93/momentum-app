package com.momentum.nextbrick;

import java.util.Locale;

/**
 * Deterministic, offline goal playbooks. Not generative AI: these are curated steps.
 * Completing a full brick advances the roadmap. Completing a smaller step only
 * moves back up toward its full brick. No external API or account required.
 */
public final class GoalRoadmap {
    private GoalRoadmap() {}

    private static final String[] CONTENT = {
        "Outline the next article around one reader question",
        "Draft the article's opening paragraph",
        "Write the first useful section of the article",
        "Draft the remaining sections of the article",
        "Add one specific example from your experience",
        "Edit the article to make it clearer and more useful",
        "Add a relevant image and two helpful links",
        "Publish the completed article",
        "Share the article with one relevant audience",
        "Review the article's search impressions or reader feedback",
        "Choose one reader question for the next article"
    };
    private static final String[] BUSINESS = {
        "Describe one specific problem someone might pay to solve",
        "Find three real examples of people facing that problem",
        "Choose one solution you could test cheaply",
        "Ask one potential customer how they currently solve it",
        "Write a simple one-paragraph offer",
        "Show the offer to three potential customers",
        "Write down objections and questions you heard",
        "Improve the offer using the feedback",
        "Ask one interested person to try your paid offer",
        "Review what people actually did, not just what they said"
    };
    private static final String[] CAREER = {
        "Identify one role that could improve your schedule or pay",
        "Find three current postings for that role",
        "List the experience and qualifications those postings require",
        "Identify one qualification gap you can realistically close",
        "Update one resume section for that role",
        "Contact one hiring manager or employee about the role",
        "Apply for one suitable opening",
        "Follow up on one application or contact",
        "Record your results and adjust your search"
    };
    private static final String[] FINANCE = {
        "List the balances, interest rates, and minimum payments",
        "Identify the payment you most need to make manageable",
        "Find one legitimate repayment or rate-reduction option",
        "Write down the eligibility requirements for that option",
        "Ask the lender one specific question about eligibility",
        "Compare the total costs before changing repayment plans",
        "Choose one affordable payment improvement to test",
        "Review the next statement for actual progress"
    };
    private static final String[] HOME = {
        "Choose one unfinished part of the project",
        "List the materials and tools needed for that part",
        "Check dimensions and safety requirements before starting",
        "Gather the tools and prepare the work area",
        "Complete one small physical part of the repair",
        "Inspect the work and fix one issue",
        "Clean up and note the next unfinished part"
    };
    private static final String[] HEALTH = {
        "Pick one realistic activity or meal habit for this week",
        "Prepare the supplies needed for that habit",
        "Complete one manageable session or meal",
        "Record what made the habit easy or difficult",
        "Remove one obstacle to repeating it",
        "Repeat the habit on your next planned day",
        "Review consistency and adjust the plan"
    };
    private static final String[] LEARNING = {
        "Choose one skill that directly supports your goal",
        "Find one practical tutorial or exercise for that skill",
        "Complete the smallest hands-on exercise",
        "Explain the idea in your own words",
        "Apply what you learned to a real problem",
        "Identify what didn't work and correct it",
        "Choose the next practical exercise"
    };
    private static final String[] GENERAL = {
        "Write down one concrete result that would move your goal forward",
        "Identify one obstacle stopping that result",
        "Find one practical way to remove the obstacle",
        "Take one 15-minute action that changes something real",
        "Check what changed because of that action",
        "Choose one follow-up action based on the result"
    };

    public static final class Next {
        public final String track;
        public final int index;
        public final String task;
        private Next(String track, int index, String task) {
            this.track = track; this.index = index; this.task = task;
        }
    }

    private static boolean contains(String s, String... words) {
        for (String w : words) if (s.contains(w)) return true;
        return false;
    }
    private static String lower(String s) { return s == null ? "" : s.toLowerCase(Locale.US); }

    public static String trackFor(String goal, String milestone, String brick) {
        String b = lower(brick);
        String m = lower(milestone);
        String g = lower(goal);
        // Prefer a clearly identified activity, then the named milestone, then goal.
        if (contains(b, "article", "blog post", "blogpost", "publish post", "content", "writing")) return "content";
        if (contains(b, "job", "resume", "interview", "application", "career")) return "career";
        if (contains(b, "loan", "budget", "refinanc", "debt", "monthly payment")) return "finance";
        if (contains(b, "repair", "bathroom", "paint", "trim", "fix the", "deck", "project at home")) return "home";
        if (contains(b, "workout", "exercise", "walk", "gym", "meal prep", "nutrition")) return "health";
        if (contains(b, "course", "learn", "practice coding", "study")) return "learning";
        if (contains(m, "article", "blog", "publish", "website content", "writing")) return "content";
        if (contains(m, "job", "career", "resume")) return "career";
        if (contains(m, "loan", "debt", "budget", "repay")) return "finance";
        if (contains(m, "house", "repair", "diy", "renovat")) return "home";
        if (contains(m, "fitness", "weight", "exercise", "nutrition", "diet")) return "health";
        if (contains(m, "learn", "study", "skill")) return "learning";
        if (contains(g, "article", "blog", "writing", "publish content")) return "content";
        if (contains(g, "job", "career", "day shift")) return "career";
        if (contains(g, "loan", "debt", "budget", "repay")) return "finance";
        if (contains(g, "home improvement", "renovat", "diy")) return "home";
        if (contains(g, "fitness", "weight", "health", "exercise")) return "health";
        if (contains(g, "learn", "study", "skill")) return "learning";
        if (contains(g, "business", "income", "freedom", "customer", "sales", "entrepreneur")) return "business";
        return "general";
    }

    private static String[] tasks(String track) {
        switch (track) {
            case "content": return CONTENT;
            case "business": return BUSINESS;
            case "career": return CAREER;
            case "finance": return FINANCE;
            case "home": return HOME;
            case "health": return HEALTH;
            case "learning": return LEARNING;
            default: return GENERAL;
        }
    }

    /** Match a manually chosen starter step to a roadmap when possible. */
    private static int matchingIndex(String track, String brick) {
        String b = lower(brick).trim();
        String[] p = tasks(track);
        for (int i=0; i<p.length; i++) if (lower(p[i]).equals(b)) return i;
        if ("content".equals(track)) {
            if (contains(b,"outline", "plan article")) return 0;
            if (contains(b,"intro", "opening paragraph")) return 1;
            if (contains(b,"first section")) return 2;
            if (contains(b,"remaining section", "draft post", "write article")) return 3;
            if (contains(b,"edit", "proofread")) return 5;
            if (contains(b,"image", "link")) return 6;
            if (contains(b,"publish", "post live")) return 7;
            if (contains(b,"share", "promote")) return 8;
            if (contains(b,"analytics", "impression", "traffic")) return 9;
            if (contains(b,"topic", "reader question", "keyword")) return 10;
        }
        return -1;
    }

    public static Next first(String goal, String milestone) {
        String track = trackFor(goal, milestone, "");
        return new Next(track, 0, tasks(track)[0]);
    }

    public static Next after(String goal, String milestone, String completed,
                             String storedTrack, int storedIndex) {
        String track = trackFor(goal, milestone, completed);
        // Preserve an active roadmap when its steps don't repeat the goal keywords.
        String[] prior = tasks(storedTrack);
        if (storedIndex >= 0 && storedIndex < prior.length
                && prior[storedIndex].equals(completed)) track = storedTrack;
        String[] p = tasks(track);
        int i = matchingIndex(track, completed);
        if (i == -1 && track.equals(storedTrack) && storedIndex >= 0 && storedIndex < p.length
                && p[storedIndex].equals(completed)) i = storedIndex;
        int next = i >= 0 ? (i+1) % p.length : 0;
        return new Next(track, next, p[next]);
    }
}
