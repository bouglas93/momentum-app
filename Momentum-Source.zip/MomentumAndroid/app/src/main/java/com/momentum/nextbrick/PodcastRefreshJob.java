package com.momentum.nextbrick;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;

/** Best-effort periodic refresh, no push server or paid background service. */
public final class PodcastRefreshJob extends JobService {
    private static final int JOB_ID = 927310;
    public static void schedule(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler==null) return;
        JobInfo job = new JobInfo.Builder(JOB_ID,
                new ComponentName(context, PodcastRefreshJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(6 * 60 * 60 * 1000L)
                .build();
        scheduler.schedule(job);
    }
    @Override public boolean onStartJob(JobParameters params) {
        new Thread(() -> {
            try {
                if (new PodcastLibrary(this).fetch()) BrickWidgetProvider.updateAll(this);
            } finally { jobFinished(params,false); }
        }, "MomentumPodcastRefresh").start();
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) { return true; }
}
