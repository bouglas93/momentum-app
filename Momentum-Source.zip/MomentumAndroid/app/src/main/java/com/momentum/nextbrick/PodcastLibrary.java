package com.momentum.nextbrick;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/** Local preference ranking for a read-only public daily podcast feed. No tokens or account. */
public final class PodcastLibrary {
    public static final String DEFAULT_URL = "https://bouglas93.github.io/momentum-app/recommendations.json";
    private final SharedPreferences prefs;

    public PodcastLibrary(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences("momentum_v1", Context.MODE_PRIVATE);
    }
    public String feedUrl() { return prefs.getString("podcast_feed_url", DEFAULT_URL); }
    public void setFeedUrl(String url) {
        String value = url.trim();
        android.net.Uri u = android.net.Uri.parse(value);
        String host = u.getHost();
        if (!"https".equalsIgnoreCase(u.getScheme()) || host == null ||
                !(host.equals("github.io") || host.endsWith(".github.io")) ||
                !value.endsWith(".json"))
            throw new IllegalArgumentException("Use an HTTPS github.io JSON feed URL");
        prefs.edit().putString("podcast_feed_url", value).commit();
    }
    public long lastSync() { return prefs.getLong("podcast_last_sync", 0); }
    public String error() { return prefs.getString("podcast_feed_error", ""); }
    private JSONObject feed() {
        try { return new JSONObject(prefs.getString("podcast_feed_json", "{}")); }
        catch (Exception ex) { return new JSONObject(); }
    }
    private JSONArray candidates() {
        JSONObject feed = feed();
        JSONArray out = new JSONArray();
        JSONObject main = feed.optJSONObject("today");
        if (main != null) out.put(main);
        JSONArray more = feed.optJSONArray("alternates");
        if (more != null) for (int i=0; i<more.length(); i++) {
            JSONObject ep = more.optJSONObject(i);
            if (ep != null) out.put(ep);
        }
        return out;
    }
    private JSONArray skipped() {
        try { return new JSONArray(prefs.getString("podcast_skipped", "[]")); }
        catch (Exception ex) { return new JSONArray(); }
    }
    private JSONObject ratings() {
        try { return new JSONObject(prefs.getString("podcast_show_ratings", "{}")); }
        catch (Exception ex) { return new JSONObject(); }
    }
    private boolean contains(JSONArray a, String id) {
        for (int i=0;i<a.length();i++) if (id.equals(a.optString(i))) return true;
        return false;
    }
    public JSONObject current() {
        JSONArray pool = candidates();
        if (pool.length()==0) return null;
        String preferred = prefs.getString("podcast_selected", "");
        JSONArray skipped = skipped();
        if (!preferred.isEmpty()) for (int i=0;i<pool.length();i++) {
            JSONObject ep = pool.optJSONObject(i);
            if (ep != null && preferred.equals(ep.optString("id")) && !contains(skipped, preferred))
                return ep;
        }
        JSONObject ratings = ratings();
        JSONObject best = null;
        double bestScore = -100000;
        String kind = pool.optJSONObject(0).optString("kind");
        for (int i=0;i<pool.length();i++) {
            JSONObject ep = pool.optJSONObject(i);
            if (ep==null || contains(skipped, ep.optString("id"))) continue;
            double score = ep.optDouble("score",0) + ratings.optInt(ep.optString("show"),0)*15;
            if (ep.optString("kind").equals(kind)) score += 12;
            if (i==0) score += 15;
            if (score > bestScore) { bestScore=score; best=ep; }
        }
        return best;
    }
    public void rate(boolean good) {
        JSONObject item = current();
        if (item == null) return;
        JSONObject ratings = ratings();
        String show = item.optString("show");
        int existing = ratings.optInt(show,0);
        try { ratings.put(show, Math.max(-3,Math.min(3,existing+(good ? 1 : -1)))); }
        catch (Exception ignored) { return; }
        prefs.edit().putString("podcast_show_ratings", ratings.toString()).commit();
        if (!good) {
            JSONArray skipped = skipped();
            String id = item.optString("id");
            if (!contains(skipped, id)) skipped.put(id);
            JSONArray bounded = new JSONArray();
            for (int i=Math.max(0,skipped.length()-250); i<skipped.length(); i++) bounded.put(skipped.opt(i));
            prefs.edit().putString("podcast_skipped", bounded.toString()).remove("podcast_selected").commit();
        }
    }
    /** Skip a particular episode for good, choose next available one locally. */
    public void next() {
        JSONObject item = current();
        if (item == null) return;
        JSONArray skipped = skipped();
        String id = item.optString("id");
        if (!contains(skipped,id)) skipped.put(id);
        // Keep a bounded list so installed apps don't accumulate endless state.
        JSONArray bounded = new JSONArray();
        for (int i=Math.max(0,skipped.length()-250);i<skipped.length();i++) bounded.put(skipped.opt(i));
        prefs.edit().putString("podcast_skipped", bounded.toString())
                .remove("podcast_selected").commit();
    }
    public void select(JSONObject item) {
        if (item != null) prefs.edit().putString("podcast_selected",item.optString("id")).commit();
    }
    public String feedDay() { return feed().optString("date", ""); }
    public boolean hasFeed() { return feed().optJSONObject("today") != null; }

    public boolean fetch() {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection)new URL(feedUrl()).openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(12000);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "MomentumAndroid/0.5");
            if (c.getResponseCode()!=200) throw new IllegalStateException("Feed HTTP " + c.getResponseCode());
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream stream = c.getInputStream()) {
                byte[] buf = new byte[4096]; int n;
                while ((n=stream.read(buf)) != -1) {
                    if (bytes.size()+n > 350000) throw new IllegalStateException("Podcast feed too large");
                    bytes.write(buf,0,n);
                }
            }
            String raw = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
            JSONObject data = new JSONObject(raw);
            if (data.optInt("version")!=1 || data.optJSONObject("today")==null)
                throw new IllegalStateException("Unexpected feed format");
            JSONObject top = data.getJSONObject("today");
            if (top.optString("id").isEmpty() || top.optString("title").isEmpty() ||
                    !top.optString("url").startsWith("https://"))
                throw new IllegalStateException("Invalid podcast episode");
            String oldDay = feedDay();
            String day = data.optString("date","");
            SharedPreferences.Editor editor = prefs.edit()
                .putString("podcast_feed_json", raw)
                .putLong("podcast_last_sync", System.currentTimeMillis())
                .remove("podcast_feed_error");
            if (!day.equals(oldDay)) editor.remove("podcast_selected");
            editor.commit();
            return true;
        } catch (Exception error) {
            prefs.edit().putString("podcast_feed_error", error.getMessage()==null ?
                    "Unable to load feed" : error.getMessage()).commit();
            return false;
        } finally { if (c!=null) c.disconnect(); }
    }
}
