# Momentum — Android native MVP

**Build a life you don't need to escape. One small step at a time.**

Momentum is a native Android app and interactive home-screen widget. It is *not* an AI-connected app yet. It's a local-first first version to test whether the core experience works before paying for an AI backend.

## Features actually implemented

- Edit a big goal, current milestone and personal why.
- Define a *Next Brick* and three progressively smaller versions. Each step is editable. The **Suggest sizes** button provides basic offline rule-based prompts (not AI).
- **Make it smaller** on the app **and widget**. When a smaller step is completed, the app logs it as a *start* and moves one level back toward the original brick. Only completing the original brick counts as a *finished brick*.
- Store progress locally using Android SharedPreferences, with a rolling 7-day count and short activity history.
- Set an optional daily Android notification, initially at 10 p.m., with editable time. Alarms are approximate to minimize battery use.
- Tap the home-screen widget's task area to open the app, or use **Make smaller** and **Done** without opening the app.

## Open and install with Android Studio

1. Extract this ZIP, then on a computer with Android Studio choose **Open** and select the `MomentumAndroid` folder (the one containing `settings.gradle`).
2. Allow Android Studio to install the Android SDK Platform 35 and use a JDK 17+ as needed, and sync Gradle (Android Gradle Plugin 8.9.2 / Gradle 8.11.1). This ZIP doesn't bundle an SDK, Gradle executable, or the Gradle wrapper JAR. Android Studio can use its installed Gradle or create a wrapper.
3. Connect an Android phone with USB debugging, or use the emulator. Click **Run** in Android Studio.
4. On your phone, long-press an empty home-screen area → **Widgets** → **Momentum** → add the widget. Its layout is intended for ~4 × 3 cells, and can be resized.
5. Edit the example vision and step in the app, then test making a step smaller in the widget.

If your Studio install requires a Gradle wrapper, use its built-in Gradle support or generate the wrapper at Gradle 8.11.1. The project does not depend on any external runtime libraries.

## Intentional limits

- No generated APK in this package; the current authoring environment has no Android SDK or Gradle installation to build or test an APK. A free GitHub Actions builder is included in the separate build kit.
- No real AI decomposition or goal-quality evaluator yet; step suggestions are intentionally transparent and basic.
- One active goal and brick at a time, with manual next-brick selection. No account syncing or backups.
- This is an engineering MVP; test notification permissions, OEM widget launchers, layouts, and alarms on an actual Android device before public release.
- Local records remain on the device; app removal deletes them. Export a backup via the app before uninstalling. Automatic Android backup is disabled.

## Project layout

`app/src/main/java/com/momentum/nextbrick/` — app, state, widget, reminder scheduling.

`app/src/main/res/layout/widget_brick.xml` — native widget.

`app/src/main/res/xml/brick_widget_info.xml` — widget dimensions/metadata.

`app/src/main/AndroidManifest.xml` — Android entry points and permissions.


## Version 0.3 — encouraging quotes

- The widget now displays a short, original, encouraging line near your Next Brick. Tap the quote to cycle to the next one; the app has a matching **Another quote** control.
- The quote also changes with the calendar day during widget refresh (Android schedules a periodic widget refresh approximately every day; exact timing is system controlled). All 24 lines are built in and work offline.
- The recommended widget height is now **4 rows** so quotes do not crowd the action controls; resize your existing widget if needed.
- Quote position is saved in backups and old Momentum v1 JSON backups still restore.
- App version updated to 0.3.0.
