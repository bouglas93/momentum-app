"""Small offline self-tests. Does not claim live RSS sources are reachable."""
import datetime as dt
import json
import os
import unittest
from pathlib import Path
from unittest.mock import patch
import recommend

class RecommendationTests(unittest.TestCase):
    def setUp(self):
        self.day=dt.date(2026,10,13)
        self.config=json.loads((Path(__file__).parent/'podcasts.json').read_text())
        self.modern=next(i for i in self.config['shows'] if i['name']=='Modern Wisdom')
        self.diary=next(i for i in self.config['shows'] if i['name']=='The Diary Of A CEO')
        self.discover=next(i for i in self.config['shows'] if i['name']=='My First Million')

    def rss(self, title='How to Build Wealth through Consistent Business Habits', duration='01:37:00'):
        return f'''<?xml version="1.0"?><rss xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd"><channel><title>Show</title><item><title>{title}</title><description>Lessons on creating a business and developing resilience.</description><pubDate>Mon, 12 Oct 2026 12:00:00 GMT</pubDate><guid>urn:show:{title}</guid><link>https://example.org/episode/123</link><itunes:duration>{duration}</itunes:duration></item></channel></rss>'''.encode()

    def test_parse_duration_and_verified_url(self):
        ep=recommend.parse_rss(self.rss(), self.modern, self.day)[0]
        self.assertEqual(ep['duration_minutes'],97)
        self.assertEqual(ep['url'],'https://example.org/episode/123')
        self.assertEqual(ep['priority'],3)

    def test_prioritize_top_favorites(self):
        modern=recommend.parse_rss(self.rss(),self.modern,self.day)[0]
        diary=recommend.parse_rss(self.rss('Building Income with Discipline'),self.diary,self.day)[0]
        lower=recommend.parse_rss(self.rss('Building Income with Discipline'),self.config['shows'][1],self.day)[0]
        self.assertTrue(recommend.score(diary,self.day)[0]>recommend.score(lower,self.day)[0])
        self.assertTrue(recommend.score(modern,self.day)[0]>0)

    def test_no_recommendation_repeats(self):
        choice=recommend.parse_rss(self.rss(),self.modern,self.day)[0]
        pick,alternates=recommend.select([choice],set(),dt.date.fromordinal(739900),self.config)
        self.assertEqual(pick['id'],choice['id'])
        again,_=recommend.select([choice],{choice['id']},dt.date.fromordinal(739900),self.config)
        self.assertIsNone(again)

    def test_short_episode_is_rejected(self):
        short=recommend.parse_rss(self.rss(duration='00:08:02'),self.modern,self.day)[0]
        self.assertEqual(recommend.score(short,self.day)[0],-9999)

    def test_new_discovery_day(self):
        day=next(dt.date.fromordinal(d) for d in range(self.day.toordinal(),self.day.toordinal()+5) if d%5==4)
        fav=recommend.parse_rss(self.rss(),self.diary,self.day)[0]
        disc=recommend.parse_rss(self.rss('New ways to make money online'),self.discover,self.day)[0]
        choice,_=recommend.select([fav,disc],set(),day,self.config)
        self.assertEqual(choice['kind'],'discovery')

    def test_url_is_not_fabricated(self):
        xml=self.rss().replace(b'<link>https://example.org/episode/123</link>',b'<link>http://not-https.example/123</link>')
        self.assertEqual(recommend.parse_rss(xml,self.modern,self.day),[])

    def test_repo_history_url(self):
        with patch.dict(os.environ,{'GITHUB_REPOSITORY':'exampleuser/momentum-app'}):
            self.assertEqual(recommend.default_history_url(),'https://exampleuser.github.io/momentum-app/history.json')

if __name__=='__main__': unittest.main()
