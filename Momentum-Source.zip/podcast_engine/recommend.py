#!/usr/bin/env python3
"""Momentum free RSS recommendation engine. Python stdlib only; no AI/API keys.

Fetch public episode metadata -> score length + subject -> enforce 3 favorites/2
new discoveries per 5-day cycle -> publish JSON to GitHub Pages. Keep a bounded
history across runs by fetching the previous publicly deployed history.json.
"""
import datetime as dt
import email.utils
import hashlib
import html
import json
import os
import re
import sys
import urllib.parse
import urllib.request
from zoneinfo import ZoneInfo
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = Path(__file__).resolve().parent
SITE = BASE.parent / "site"
ITUNES_NS = "{http://www.itunes.com/dtds/podcast-1.0.dtd}"
ATOM_NS = "{http://www.w3.org/2005/Atom}"
def default_history_url():
    owner, _, repo = os.getenv("GITHUB_REPOSITORY", "bouglas93/momentum-app").partition("/")
    if not owner or not repo:
        raise ValueError("Set GITHUB_REPOSITORY=owner/repository")
    return f"https://{owner.lower()}.github.io/{repo}/history.json"

USER_AGENT = "MomentumPodcastRecommendations/1.0 (+personal noncommercial RSS reader)"
TOPIC_WEIGHTS = {
    "business": 4, "businesses": 4, "entrepreneur": 5, "founder": 5,
    "startup": 4, "building": 2, "money": 5, "wealth": 4,
    "financial": 5, "income": 5, "cashflow": 5, "marketing": 5,
    "selling": 4, "sales": 4, "brand": 3, "creator": 3,
    "discipline": 7, "habits": 6, "habit": 5, "focus": 5,
    "grit": 6, "resilience": 7, "resilient": 6,
    "determination": 7, "consistency": 7, "mindset": 5,
    "confidence": 3, "agency": 5, "action": 4,
    "execution": 6, "motivation": 4, "purpose": 4,
    "learning": 3, "leadership": 3, "failure": 4,
    "psychology": 3, "risk": 3, "freedom": 4, "time": 1,
    "systems": 4, "productivity": 4, "strategy": 4,
    "invest": 4, "investing": 4, "decisions": 3,
    "self-improvement": 5, "self improvement": 5, "goals": 5,
    "alex hormozi": 3, "james clear": 7, "david goggins": 3,
}
PENALTIES = {
    "highlight": -8, "replay": -8, "best of": -9,
    "preview": -8, "trailer": -18, "reaction": -3,
    "highlights": -9, "clips": -10, "shorts": -12,
    "mel robbins": -30, "knowledge project": -40,
    "celebrity gossip": -14, "peptides": -8, "supplement": -6,
    "gambling": -12, "betting": -10, "crypto price": -6,
    "underground": -20, "members only": -20,
}

def download(url, max_bytes=3500000):
    if not url.startswith("https://"):
        raise ValueError("Only HTTPS feeds are permitted")
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/rss+xml, application/xml, text/xml, application/json, */*"})
    with urllib.request.urlopen(request, timeout=20) as response:
        data = response.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise ValueError("Remote feed too large")
    return data

def node_text(node, path, default=""):
    found = node.find(path)
    return ((found.text or "").strip() if found is not None else default)

def duration_minutes(raw):
    value = (raw or "").strip()
    if not value:
        return None
    parts = value.split(":")
    try:
        if len(parts) == 1: return round(int(parts[0]) / 60)
        if len(parts) == 2: return round(int(parts[0]) + int(parts[1]) / 60)
        if len(parts) == 3: return round(int(parts[0]) * 60 + int(parts[1]) + int(parts[2]) / 60)
    except ValueError: pass
    return None

def parse_date(raw):
    try:
        value = email.utils.parsedate_to_datetime(raw)
        if value: return value.date()
    except (TypeError, ValueError, IndexError): pass
    try: return dt.datetime.fromisoformat(raw.replace("Z", "+00:00")).date()
    except (TypeError, ValueError): return None

def clean(raw):
    no_tags = re.sub(r"<[^>]*>", " ", raw or "")
    result = html.unescape(no_tags)
    return re.sub(r"\s+", " ", result).strip()

def safe_url(raw):
    if not raw: return ""
    p = urllib.parse.urlsplit(raw.strip())
    return raw.strip() if p.scheme == "https" and p.hostname else ""

def parse_rss(xml_bytes, show, today=None):
    today = today or dt.date.today()
    root = ET.fromstring(xml_bytes)
    entries = root.findall("./channel/item")
    if not entries:
        entries = root.findall(f"./{ATOM_NS}entry")
    result = []
    for item in entries[:90]:
        title = clean(node_text(item, "title") or node_text(item, f"{ATOM_NS}title"))
        if not title: continue
        descr = clean(node_text(item, "description") or node_text(item, f"{ITUNES_NS}summary") or node_text(item, f"{ATOM_NS}summary"))
        url = safe_url(node_text(item, "link"))
        if not url:
            for link in item.findall(f"{ATOM_NS}link"):
                url = safe_url(link.get("href", ""))
                if url: break
        if not url: url = safe_url(node_text(item, "guid"))
        if not url: continue  # Never invent a direct episode link.
        released = parse_date(node_text(item, "pubDate") or node_text(item, f"{ATOM_NS}published") or node_text(item, f"{ATOM_NS}updated"))
        if released and ((today - released).days > 210 or released > today + dt.timedelta(days=1)):
            continue
        duration = duration_minutes(node_text(item, f"{ITUNES_NS}duration"))
        content = (title + " " + descr[:1200]).lower()
        if any(block in content for block in ("exclusively on jocko underground", "paid members only")):
            continue
        ident = node_text(item, "guid") or url
        uid = hashlib.sha256((show["name"].lower()+"|"+ident).encode("utf-8")).hexdigest()[:20]
        result.append({
            "id": uid, "show": show["name"], "kind": show["kind"],
            "priority": show.get("priority", 0),
            "title": title[:220], "url": url, "duration_minutes": duration,
            "released": released.isoformat() if released else None,
            "description": descr[:360],
        })
    return result

def score(ep, today):
    title = ep["title"].lower()
    desc = ep["description"].lower()
    combined = title + " " + desc
    value = 0.0
    matched = []
    for keyword, weight in TOPIC_WEIGHTS.items():
        expression = r"(?<!\w)" + re.escape(keyword) + r"(?!\w)"
        if re.search(expression, title):
            value += weight * 2.0
            matched.append(keyword)
        elif re.search(expression, desc):
            value += weight * 0.34
            matched.append(keyword)
    for keyword, penalty in PENALTIES.items():
        if keyword in title: value += penalty * 2
        elif keyword in desc[:120]: value += penalty * 0.25
    if ep["duration_minutes"] is not None:
        minutes = ep["duration_minutes"]
        if minutes < 35: return -9999, []
        if 55 <= minutes <= 170: value += 5
        if minutes > 230: value -= 5
    if ep["released"]:
        age = max(0, (today - dt.date.fromisoformat(ep["released"])).days)
        value += max(-10, 5 - age / 18)
    if ep["kind"] == "favorite": value += 2
    # Source-level preference: top-two favorite shows get a deliberate advantage,
    # but a weaker episode can still lose to a better match from another show.
    value += ep.get("priority", 0) * 3.5
    return round(value, 2), matched[:5]

def select(episodes, seen, day, config, recent_shows=()):
    # Exactly 3 of every 5 days prefer favorites; fallback if pool empty.
    choose_favorite = (day.toordinal() % 5) in (0, 1, 2)
    primary_kind = "favorite" if choose_favorite else "discovery"
    ranked = []
    for ep in episodes:
        if ep["id"] in seen: continue
        s, matches = score(ep, day)
        if s <= -10: continue  # Avoid very weak candidates.
        # Known previously recommended episodes from the user's ChatGPT history.
        # This can't automatically discover other podcast listening history.
        if ep["show"] == "Modern Wisdom" and re.search(r"(?:^|\D)#?946(?:\D|$)", ep["title"]): continue
        s -= min(9, recent_shows.count(ep["show"]) * 4)
        ranked.append((s, ep, matches))
    ranked.sort(key=lambda x: (-x[0], x[1]["show"], x[1]["id"]))
    preferred = [x for x in ranked if x[1]["kind"] == primary_kind]
    winner = (preferred or ranked)[0] if (preferred or ranked) else None
    if not winner: return None, []
    rest = [x for x in ranked if x[1]["id"] != winner[1]["id"]]
    # Alternate pool spans different shows as far as possible.
    picked = [winner]
    shows = {winner[1]["show"]}
    for item in rest:
        if item[1]["show"] not in shows:
            picked.append(item)
            shows.add(item[1]["show"])
        if len(picked) >= 7: break
    for item in rest:
        if len(picked) >= 7: break
        if item[1]["id"] not in {x[1]["id"] for x in picked}: picked.append(item)
    def present(entry):
        s, ep, matches = entry
        return {**ep, "score": s,
                "reason": ("Relevant topics: " + ", ".join(matches[:3])) if matches else "From your selected podcast feeds",
                "spotify_search": "https://open.spotify.com/search/" + urllib.parse.quote(ep["show"] + " " + ep["title"], safe="")}
    return present(winner), [present(i) for i in picked[1:]]

def load_history(url):
    try:
        history = json.loads(download(url, 150000))
        if isinstance(history, dict) and isinstance(history.get("days"), list):
            return {"days": [i for i in history["days"] if isinstance(i, dict)][-150:]}
    except Exception as e:
        print("History unavailable (first run or Pages not yet deployed):", str(e)[:150], file=sys.stderr)
    return {"days": []}

def main():
    SITE.mkdir(exist_ok=True)
    config = json.loads((BASE / "podcasts.json").read_text(encoding="utf-8"))
    today = dt.datetime.now(ZoneInfo("America/New_York")).date()
    # GitHub schedules are best-effort. Local calendar day is US Eastern.
    history_url = os.getenv("HISTORY_URL", default_history_url())
    history = load_history(history_url)
    rows = history["days"]
    existing = next((x for x in rows if x.get("date") == today.isoformat()), None)
    seen = {x.get("episode_id") for x in rows if x.get("episode_id")}
    episodes = []
    errors = []
    for show in config["shows"]:
        try:
            parsed = parse_rss(download(show["feed"]), show, today)
            episodes.extend(parsed)
            print(f"{show['name']}: {len(parsed)} linked episodes")
        except Exception as exc:
            errors.append(f"{show['name']}: {type(exc).__name__}")
            print(f"WARNING feed fetch failed for {show['name']}: {exc}", file=sys.stderr)
    if not episodes:
        raise RuntimeError("Every podcast feed failed; refusing to publish an empty recommendation")
    # Preserve the day's earlier pick on workflow retries, when still available.
    chosen, alternates = select(episodes, seen - ({existing.get('episode_id')} if existing else set()), today,
                                config, [i.get("show", "") for i in rows[-3:]])
    if existing:
        same = next((e for e in episodes if e["id"] == existing.get("episode_id")), None)
        if same:
            score_value, matches = score(same, today)
            chosen = {**same, "score": score_value,
                      "reason": ("Relevant topics: " + ", ".join(matches[:3])) if matches else "From your selected podcast feeds",
                      "spotify_search": "https://open.spotify.com/search/" + urllib.parse.quote(same["show"] + " " + same["title"], safe="")}
    if chosen is None:
        raise RuntimeError("No eligible new episodes: keeping previous recommendation published")
    if not existing:
        rows.append({"date": today.isoformat(), "episode_id": chosen["id"], "show": chosen["show"]})
    history["days"] = rows[-150:]
    payload = {"version": 1,
               "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
               "date": today.isoformat(), "selection_method": "RSS title/description keyword ranking, not human-reviewed or AI-generated",
               "today": chosen, "alternates": alternates, "feed_errors": errors}
    (SITE / "recommendations.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (SITE / "history.json").write_text(json.dumps(history, indent=2) + "\n", encoding="utf-8")
    print("PICK:", chosen["show"], "—", chosen["title"])

if __name__ == "__main__": main()
